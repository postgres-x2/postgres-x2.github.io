/*-------------------------------------------------------------------------
 *
 * signature.h
 *
 *    Signature of module of Postgres-XC configuration and operation tool.
 *
 * Copyright (c) 2013 Postgres-XC Development Group
 *
 *-------------------------------------------------------------------------
 */
#ifndef SIGNATURE_H
#define SIGNATURE_H
/* Signature file to identify the make */
#define signature "130423_1123_240412000"
#endif /* SIGNATURE_H */
