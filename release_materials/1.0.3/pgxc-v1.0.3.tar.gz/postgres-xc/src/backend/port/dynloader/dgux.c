/* Dummy file used for nothing at this point
 *
 * see dgux.h
 *
 * src/backend/port/dynloader/dgux.c
 */
