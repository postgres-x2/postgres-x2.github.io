/* src/backend/port/dynloader/irix.c */

/* Dummy file used for nothing at this point
 *
 * see irix.h
 */
